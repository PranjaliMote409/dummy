package com.cg.mra.exception;
//------------------------   <MobileRechargeApplication_152643> --------------------------
public interface IAccountException {

	String ERROR1 = "Mobile number should be of 10 digits!!!";
	

}
